#!/bin/zsh
besu --genesis-file=../genesis.json --config-file=config-bonsai.toml --sync-mode=SNAP --sync-min-peers=1 -l INFO

